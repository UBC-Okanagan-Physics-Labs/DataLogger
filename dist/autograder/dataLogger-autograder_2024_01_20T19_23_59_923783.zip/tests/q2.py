OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(num, float)\nTrue',
                                       'failure_message': 'text must be a string (enclosed in single or double quotes).',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> test = True\n>>> if isinstance(num, float):\n...     test = num == 2.34\n>>> test\nTrue',
                                       'failure_message': 'Double check the string you entered.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
