OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(text, str)\nTrue',
                                       'failure_message': 'text must be a string (enclosed in single or double quotes).',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': '>>> test = True\n>>> if isinstance(text, str):\n...     test = text == "hello world"\n>>> test\nTrue',
                                       'failure_message': 'Double check the string you entered.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
